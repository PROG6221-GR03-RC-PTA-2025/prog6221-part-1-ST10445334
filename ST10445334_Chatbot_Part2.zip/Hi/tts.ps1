Add-Type -TypeDefinition @"
using System;
using System.Speech.Synthesis;
public class TTS
{
    public static void Speak(string text)
    {
        using (SpeechSynthesizer synth = new SpeechSynthesizer())
        {
            synth.SetOutputToWaveFile("greeting.wav");
            synth.Speak(text);
        }
    }
}
"@ -Language CSharp
[TTS]::Speak("Hello! Welcome to the Cybersecurity Awareness Bot. I’m here to help you stay safe online.")
