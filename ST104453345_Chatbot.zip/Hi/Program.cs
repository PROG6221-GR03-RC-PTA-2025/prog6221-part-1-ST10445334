﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Media;
using System.Speech.Synthesis;
using System.Threading;
using System.Timers;

class CyberSecurityChatbot
{
    static SpeechSynthesizer synthesizer = new SpeechSynthesizer();
    static System.Timers.Timer questionTimer;
    static bool timeUp;
    static char userAnswer = '\0';

    static void Main()
    {
        synthesizer.SetOutputToDefaultAudioDevice(); // Set up text-to-speech
        PlayGreeting();
        DisplayAnimatedLogo();
        StartChat();
    }

    static void PlayGreeting()
    {
        
        using (SoundPlayer player = new SoundPlayer("Voice1.wav"))
        {
            try
            {
                player.Load();
                player.PlaySync();
                Console.WriteLine("Audio playback completed.");
            }

            catch (Exception ex)
            {
                SpeakText("Welcome to the Cybersecurity Awareness Bot.");
                Console.WriteLine("Error playing sound: " + ex.Message);
            }
        }
    }

    static void DisplayAnimatedLogo()
    {
        string[] logo = new string[]
        {
            "\u001b[31m        ██████╗ ██╗   ██╗██████╗ ███████╗  ██████╗  ██████╗ ███████╗", // Red
            "\u001b[33m        ██╔══██╗██║   ██║██╔══██╗██╔════╝ ██╔═══██╗██╔═══██╗██╔════╝", // Yellow
            "\u001b[32m        ██████╔╝██║   ██║██████╔╝███████╗ ██║   ██║██║   ██║███████╗", // Green
            "\u001b[36m        ██╔═══╝ ██║   ██║██╔═══╝ ╚════██║ ██║   ██║██║   ██║╚════██║", // Cyan
            "\u001b[34m        ██║     ╚██████╔╝██║     ███████║ ╚██████╔╝╚██████╔╝███████║", // Blue
            "\u001b[35m        ╚═╝      ╚═════╝ ╚═╝     ╚══════╝  ╚═════╝  ╚═════╝ ╚══════╝\u001b[0m"  // Purple & Reset
        };

        Random rnd = new Random();
        foreach (string line in logo)
        {
            Console.WriteLine(line);
            Thread.Sleep(200);
        }
        Console.WriteLine("\n\u001b[33m✨ Welcome to the Cybersecurity Awareness Chatbot! ✨\u001b[0m");
    }



    static void StartChat()
    {
        Console.Write("\nEnter your name: ");
        string userName = Console.ReadLine().Trim();
        if (string.IsNullOrEmpty(userName)) userName = "User";

        SpeakText($"Hello, {userName}! Type 'quiz' to test your cybersecurity knowledge or ask a question.");
        Console.WriteLine("\nType 'quiz' to test your cybersecurity knowledge or ask a question.");
        Console.WriteLine("Type 'exit' to end the chat.\n");

        Dictionary<string, string> responses = new Dictionary<string, string>()
        {
            { "how are you", "I'm just a bot, but I'm here to help!" },
            { "what’s your purpose", "I provide cybersecurity awareness and tips." },
            { "c", "Use strong, unique passwords and enable 2FA!" },
            { "phishing", "Never click suspicious links! Verify sender authenticity." },
            { "social engineering", "Cybercriminals manipulate people to gain access to data." },
            { "malware", "Malware includes viruses, worms, and trojans. Keep your antivirus updated!" },
            { "public wifi", "Avoid using public Wi-Fi for sensitive transactions. Use a VPN if necessary." }
        };

        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\nYou: ");
            Console.ResetColor();
            string userInput = Console.ReadLine().ToLower().Trim();

            if (userInput == "exit")
            {
                SpeakText("Goodbye! Stay safe online.");
                Console.WriteLine("\nGoodbye! Stay safe online.");
                break;
            }

            if (userInput == "quiz")
            {
                StartQuiz();
                continue;
            }

            string response = GetResponse(userInput, responses);
            SpeakText(response);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Bot: {response}");
            Console.ResetColor();

            LogConversation(userName, userInput, response);
            Thread.Sleep(500);
        }
    }

    static string GetResponse(string input, Dictionary<string, string> responses)
    {
        foreach (var key in responses.Keys)
        {
            if (input.Contains(key)) return responses[key];
        }
        return "I didn’t quite understand that. Could you rephrase?";
    }

    static void LogConversation(string userName, string userInput, string botResponse)
    {
        string logEntry = $"{DateTime.Now}: {userName} asked '{userInput}', Bot replied '{botResponse}'";
        File.AppendAllText("chat_log.txt", logEntry + Environment.NewLine);
    }

    static void StartQuiz()
    {
        Console.ForegroundColor = ConsoleColor.Blue;
        SpeakText("Welcome to the Cybersecurity Quiz! Answer the following questions within 10 seconds.");
        Console.WriteLine("\nWelcome to the Cybersecurity Quiz! Answer within 10 seconds per question.");
        Console.ResetColor();

        List<(string Question, string[] Options, char Answer)> quizQuestions = new List<(string, string[], char)>
        {
            ("What does '2FA' stand for?", new string[] { "A) Two-Factor Authentication", "B) Two-Fold Authorization", "C) Two-Feature Access", "D) Total Firewall Activation" }, 'A'),
            ("Which is an example of phishing?", new string[] { "A) Using a VPN", "B) Fake emails stealing info", "C) Strong passwords", "D) Enabling firewall" }, 'B'),
            ("Why avoid public Wi-Fi?", new string[] { "A) It’s slow", "B) Drains battery", "C) Hackers can steal data", "D) Too expensive" }, 'C'),
            ("What is malware?", new string[] { "A) Protective software", "B) Cyber insurance", "C) Malicious software", "D) Password manager" }, 'C'),
            ("Best way to create a password?", new string[] { "A) 'password123'", "B) Password manager", "C) Write on paper", "D) Only letters/numbers" }, 'B'),
            ("What does HTTPS mean?", new string[] { "A) HyperText Transfer Protocol Secure", "B) High Tech Protocol System", "C) Hackers Test Password Security", "D) Hosting Trusted Pages" }, 'A')
        };

        int score = 0;

        foreach (var (question, options, answer) in quizQuestions)
        {
            Console.WriteLine($"\n{question}");
            SpeakText(question);

            foreach (var option in options)
            {
                Console.WriteLine(option);
                SpeakText(option);
            }

            userAnswer = '\0';
            timeUp = false;
            StartTimer(10);

            while (!timeUp && userAnswer == '\0')
            {
                string input = Console.ReadLine().ToUpper().Trim();
                if (input.Length == 1 && "ABCD".Contains(input))
                {
                    userAnswer = input[0];
                }
            }

            questionTimer.Stop();

            if (timeUp)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                SpeakText("Time's up! No answer recorded.");
                Console.WriteLine("Time's up! No answer recorded.");
            }
            else if (userAnswer == answer)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                SpeakText("Correct!");
                Console.WriteLine("Correct!");
                score++;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                SpeakText($"Wrong! The correct answer was {answer}");
                Console.WriteLine($"Wrong! The correct answer was {answer}");
            }

            Console.ResetColor();
        }

        SpeakText($"Quiz completed! Your score is {score} out of {quizQuestions.Count}");
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"\nQuiz Completed! Your Score: {score}/{quizQuestions.Count}");
        Console.ResetColor();
    }

    static void StartTimer(int seconds)
    {
        questionTimer = new System.Timers.Timer(seconds * 1000);
        questionTimer.Elapsed += (sender, e) => { timeUp = true; questionTimer.Stop(); };
        questionTimer.Start();
    }

    static void SpeakText(string text)
    {
        synthesizer.SpeakAsync(text);
    }
}

